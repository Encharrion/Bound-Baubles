Baubles
=======

A mod api that adds 7 bauble slots to the players inventory.

The mod has no real content - the idea is that other mods will use this one and its API to add their own baubles.

The 7 slots added are an amulet, belt, head, body, charm and 2 ring slots.

Baubles is distributed under the Attribution-NonCommercial-ShareAlike 3.0 Unported (CC BY-NC-SA 3.0) license.

